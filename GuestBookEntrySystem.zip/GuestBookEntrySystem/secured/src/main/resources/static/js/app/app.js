var app = angular.module('guestBookEntryApp',['ui.router','ngStorage','ngResource','ngRoute','ngCookies','angular-jwt']);
// var app = angular.module('guestBookEntryApp',['ui.router','ngStorage','ngResource','ngRoute','ngCookies','angular-jwt']);

app.constant('urls', {
    BASE: 'http://localhost:8080/',
    USER_SERVICE_API : 'http://localhost:8080/guestBookEntries/'
});

//app.config(['$stateProvider', '$urlRouterProvider',
//    function($stateProvider, $urlRouterProvider) {
//
//	//$urlRouterProvider.otherwise('/home');
//
//        $stateProvider
//            .state('home', {
//                url: '/',
//                //templateUrl: 'partials/list',
//                templateUrl: 'views/content.html',
//                controller:'UserController',
//                controllerAs:'ctrl',
//                resolve: {
//                    users: function ($q, UserService) {
//                        console.log('Load all users');
//                        var deferred = $q.defer();                        
//                        UserService.loadAllUsers().then(deferred.resolve, deferred.resolve);
//                        return deferred.promise;
//                    }
//                }
//            }).state('login', {
//            url: '/login',
//            //templateUrl: 'partials/list',
//            templateUrl: 'views/login.html',
//            controller:'LoginController',
//            controllerAs:'ctrll',
//            resolve: {
//                loginData: function ($q, UserService) {
//                    console.log('User Login');
//                    //var deferred = $q.defer();
//                    //UserService.loadAllUsers().then(deferred.resolve, deferred.resolve);
//                    //return deferred.promise;
//                }
//            }
//        });
//        $urlRouterProvider.otherwise('/');
//    }]);



app.factory('genInterceptor', ['$q','$injector','$httpParamSerializer','$window', '$location', 
                                      function($q, $injector,$httpParamSerializer,$window, $location) {
    var interceptor = {
    		 
    			// optional method
    			'request' : function(config) {
    				// do something on success
    				console.info('--------request-------');    				
    				//console.log(' request url: ' + config.url);
    				if(config.url.indexOf('greeting')!= -1 || config.url.indexOf('login')!= -1 ||  config.url.indexOf('token')!= -1)    					
					{
    					// do not add authorization header for these requests
    					console.info('--------Bearer token is NOT added-------'); 
					}
    				else
    				{
    					console.info('--------Bearer token added-------'); 
    					config.headers.Authorization = 'Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhdWQiOlsidGVzdGp3dHJlc291cmNlaWQiXSwidXNlcl9uYW1lIjoiZG9yYWlyYWoiLCJzY29wZSI6WyJyZWFkIiwid3JpdGUiXSwiZXhwIjoxNTMwNTA2MTExLCJhdXRob3JpdGllcyI6WyJTVEFOREFSRF9VU0VSIl0sImp0aSI6IjU0OWRmZDk2LWY2MmEtNDI4NC1hODk2LTU1YmQ0NWExYjdlZSIsImNsaWVudF9pZCI6InRlc3Rqd3RjbGllbnRpZCJ9.xQtwfoGvtE9DFhP8A8Tt9iKzDSqA7iVi6cIA110ECBg';
    				}
    				
    				//console.log(' request headers: ' + JSON.stringify(config.headers));
    				//config.headers = config.headers || {};
    			    //if (!$window.localStorage.token) {    	
    			    //	console.info('----login----request-------');
    			    	//$location.path('/login');
    			    	//window.location.href = "login";
    			    	//$window.localStorage.token
    			      //config.headers.Authorization = 'Bearer ' + $window.localStorage.token;
    			    //}
    			    //window.location.href = "login";
    				return config;
    			},

    			// optional method
    			'requestError' : function(rejection) {
    				// do something on error
    				if (canRecover(rejection)) {
    					 
    					return responseOrNewPromise
    				}
    				//alert('before request reject');
    				return $q.reject(rejection);
    			},

    			// optional method
    			'response' : function(response) {
    				// do something on success
    				//alert('response');
    				return response;
    			},

    			// optional method
    			'responseError' : function(response) {    				
					
//    				if (response.status == 401){
//    	                
//    	                var $http = $injector.get('$http');
//    	                var $cookies = $injector.get('$cookies');
//    	                var deferred = $q.defer();
//
//    	                var refreshData = {grant_type:"refresh_token"};
//    	                
//    	                var req = {
//    	                    method: 'POST',
//    	                    url: "oauth/token",
//    	                    headers: {"Content-type": "application/x-www-form-urlencoded; charset=utf-8"},
//    	                    data: $httpParamSerializer(refreshData)
//    	                }
//    		
//    	                $http(req).then(
//    	                    function(data){
//    	                        $http.defaults.headers.common.Authorization= 'Bearer ' + data.data.access_token;
//    	                        var expireDate = new Date (new Date().getTime() + (1000 * data.data.expires_in));
//    	                        $cookies.put("access_token", data.data.access_token, {'expires': expireDate});
//    	                        $cookies.put("validity", data.data.expires_in);
//    	                        window.location.href="index";
//    	                    },function(){
//    	                        console.log("error");
//    	                        $cookies.remove("access_token");
//    	                        window.location.href = "login";
//    	                    }
//    	                );
//
//    	                // make the backend call again and chain the request
//    	                return deferred.promise.then(function() {
//    	                    return $http(response.config);
//    	                });
//    	            }
//    	            return $q.reject(response);
    			}
    		};
    
    return interceptor;
    		
        /* responseError: function(response) {
            if (response.status == 401){
                
                var $http = $injector.get('$http');
                var $cookies = $injector.get('$cookies');
                var deferred = $q.defer();

                var refreshData = {grant_type:"refresh_token"};
                
                var req = {
                    method: 'POST',
                    url: "oauth/token",
                    headers: {"Content-type": "application/x-www-form-urlencoded; charset=utf-8"},
                    data: $httpParamSerializer(refreshData)
                }
	
                $http(req).then(
                    function(data){
                        $http.defaults.headers.common.Authorization= 'Bearer ' + data.data.access_token;
                        var expireDate = new Date (new Date().getTime() + (1000 * data.data.expires_in));
                        $cookies.put("access_token", data.data.access_token, {'expires': expireDate});
                        $cookies.put("validity", data.data.expires_in);
                        window.location.href="index";
                    },function(){
                        console.log("error");
                        $cookies.remove("access_token");
                        window.location.href = "login";
                    }
                );

                // make the backend call again and chain the request
                return deferred.promise.then(function() {
                    return $http(response.config);
                });
            }
            return $q.reject(response);
        } */
   // };
   // return interceptor;
}]);

app.config(['$httpProvider', function($httpProvider) {  
    $httpProvider.interceptors.push('genInterceptor');
}]);