package com.gbes.restfulapi.repository;

import org.springframework.data.repository.CrudRepository;

import com.gbes.restfulapi.model.User;

/**
 * Created by nydiarra on 06/05/17.
 */
public interface UserRepository extends CrudRepository<User, Long> {
	User findByUsername(String username);
}
