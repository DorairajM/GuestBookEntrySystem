package com.gbes.restfulapi.model;

import java.util.Date;

public class Greeting {

	private long id;

	private String content;

	private String datetime;

	public Greeting() {
		this.id = -1;
		this.content = "";
		this.datetime = GuestBookEntry.getDateateAsString(new Date());
	}

	public Greeting(long id, String content) {
		this.id = id;
		this.content = content;
		this.datetime = GuestBookEntry.getDateateAsString(new Date());
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getDatetime() {
		return datetime;
	}

	public void setDatetime(String datetime) {
		this.datetime = datetime;
	}

}
