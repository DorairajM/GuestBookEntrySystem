package com.gbes.restfulapi.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gbes.restfulapi.model.GuestBookEntry;

/*@RepositoryRestResource(collectionResourceRel = "guestBooks", path = "guestBooks")*/
public interface GuestBookRepository extends JpaRepository<GuestBookEntry, Integer> { // PagingAndSortingRepository<GuestBookEntry,
																						// Long>
																						// {
	// List<GuestBookEntry> findByName(@Param("name") String name);
}