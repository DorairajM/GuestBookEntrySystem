package com.gbes.restfulapi.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gbes.restfulapi.model.GuestBookEntry;
import com.gbes.restfulapi.repository.GuestBookRepository;

@RestController
@RequestMapping(value = "/guestBookEntries")
public class GuestBookRestController {

	int id = 0;
	@Autowired
	GuestBookRepository guestBookRepository;

	@CrossOrigin(origins = "http://localhost:8090")
	// @GetMapping(value = "/guestBook", produces = "application/json")
	@GetMapping()
	public List<GuestBookEntry> get() throws Exception {
		return guestBookRepository.findAll();
	}

	@CrossOrigin(origins = "http://localhost:8090")
	@GetMapping(value = "/{id}")
	public GuestBookEntry getOne(@PathVariable("id") Integer id) throws Exception {

		GuestBookEntry gbe = guestBookRepository.findOne(id);
		return gbe;
	}

	@PostMapping()
	public GuestBookEntry create(@RequestBody GuestBookEntry guestBookEntry) throws Exception {
		id++;
		guestBookEntry.setId(id);
		return guestBookRepository.save(guestBookEntry);
	}

	// @PatchMapping(value = "/guestBook/{id}", produces = "application/json")
	@PatchMapping(value = "/{id}")
	public GuestBookEntry patch(@PathVariable("id") Integer id, @RequestBody GuestBookEntry guestBookEntry)
			throws Exception {

		GuestBookEntry bk = guestBookRepository.findOne(id);
		if (bk == null) {
			throw new Exception("Resource Item not found");
		}
		guestBookEntry.setId(bk.getId());
		// bk.setComment(guestBookEntry.getComment());
		// bk.setComment(guestBookEntry.getComment());
		guestBookEntry = guestBookRepository.save(guestBookEntry);
		guestBookEntry = guestBookRepository.findOne(id);
		
		return guestBookEntry;

	}

	// @DeleteMapping(value = "/guestBook/{id}", produces = "application/json")
	@DeleteMapping(value = "/{id}")
	public void delete(@PathVariable("id") Integer id) throws Exception {
		GuestBookEntry bk = guestBookRepository.getOne(id);
		if (bk == null) {
			throw new Exception("Resource Item not found");
		}
		guestBookRepository.delete(bk);
	}
}
