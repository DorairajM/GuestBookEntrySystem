package com.gbes.restfulapi.model;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Length;

@Entity
@Table(name = "guest_book")
public class GuestBookEntry {

	Integer id;
	String name;
	String comment;
	Date creationDate;
	String creationDateAsString;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@NotNull
	@Length(min = 3, max = 100)
	public String getName() {
		return name;
	}

	public void setName(String guestName) {
		this.name = guestName;
	}

	@Length(min = 0, max = 500)
	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	@NotNull
	public Date getCreationDate() {
		if (creationDate == null)
			return new Date();

		return creationDate;
	}

	public void setCreationDate(Date entryDateTime) {
		this.creationDate = entryDateTime;
	}
	// yyyy-MM-dd'T'HH:mm:ss.SSSZ

	@Transient
	public String getCreationDateateAsString() {

		return getDateateAsString(getCreationDate());
	}

	public void setCreationDateateAsString(String creationDateAsString) {
		this.creationDateAsString = creationDateAsString;
		setCreationDate(getDateObj(creationDateAsString));
	}

	static final String format = "yyyy-MM-dd'T'HH:mm:ss.SSS";

	@Transient
	public Date getDateObj(String date) {

		if (date == null || date.equals(""))
			return new Date();

		SimpleDateFormat smpleDateFormate = null;

		try {
			smpleDateFormate = new SimpleDateFormat(format);

			return smpleDateFormate.parse(date);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return new Date();
	}

	public static String getDateateAsString(Date date) {

		if (date == null)
			return "";

		SimpleDateFormat smpleDateFormate = null;

		try {
			smpleDateFormate = new SimpleDateFormat(format);

			return smpleDateFormate.format(date);
		} catch (Exception e) {

			e.printStackTrace();
		}

		return "";
	}

}
