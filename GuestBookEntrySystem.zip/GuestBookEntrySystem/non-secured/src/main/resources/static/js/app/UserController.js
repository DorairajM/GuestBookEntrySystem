'use strict';
var websiteApp = angular.module('guestBookEntryApp');
websiteApp.controller('UserController',
    ['UserService','$scope','$resource','$http','$httpParamSerializer','$cookies','jwtHelper','$timeout',  
     function( UserService, $scope,$resource,$http,$httpParamSerializer,$cookies,jwtHelper,$timeout) {

        var self = this;
        self.user = {};
        self.greeting = {};
        self.users=[];

        self.submit = submit;
        self.getAllUsers = getAllUsers;
        self.createUser = createUser;
        self.updateUser = updateUser;
        self.removeUser = removeUser;
        self.editUser = editUser;
        self.reset = reset;
        self.refreshList = refreshList;

        self.successMessage = '';
        self.errorMessage = '';
        self.done = false;

        self.corsMessage="";
        init();
       
        function init()
        {	
        	$http.get("http://localhost:8090/greeting-javaconfig")
		       .then(function(response) {
		    	   if(response) {
			    	   	self.greeting = response.data;
			    	   	// https://stackoverflow.com/questions/21102690/angularjs-not-detecting-access-control-allow-origin-header
			    	   	//angular.element('.greeting-content').append(data.content+', Datetime:'+data.datetime);
			    	   	
			    	   	self.corsMessage= self.greeting.content+', Datetime:'+self.greeting.datetime;
			    	   	console.log(' self.greeting '+self.corsMessage);
	    		   }
		      },function(response) {
		    	  console.error('Error while loading greeting');
		      });
        }
        function submit() {
            console.log('Submitting');
            if (self.user.id === undefined || self.user.id === null) {
                console.log('Saving New User', self.user);
                createUser(self.user);
            } else {
                updateUser(self.user, self.user.id);
                console.log('User updated with id ', self.user.id);
            }
        }
        function reset(){
        	console.log('resetting.....');
            self.successMessage='';
            self.errorMessage='';
            self.user={};
            $scope.myForm.$setPristine(); //reset Form
        }
        function createUser(user) {
            console.log('About to create user');
            UserService.createUser(user)
                .then(
                    function (response) {
                        console.log('User created successfully');
                        self.successMessage = 'User created successfully';
                        self.errorMessage='';
                        self.done = true;
                        self.user={};
                        $scope.myForm.$setPristine();
                    },
                    function (errResponse) {
                        console.error('Error while creating User');
                        self.errorMessage = 'Error while creating User: ' + errResponse.data.errorMessage;
                        self.successMessage='';
                    }
                );
        }


        function updateUser(user, id){
            console.log('About to update user');
            UserService.updateUser(user, id)
                .then(
                    function (response){
                        console.log('User updated successfully');
                        self.successMessage='User updated successfully';
                        self.errorMessage='';
                        self.done = true;
                        $scope.myForm.$setPristine();
                    },
                    function(errResponse){
                        console.error('Error while updating User');
                        self.errorMessage='Error while updating User '+errResponse.data;
                        self.successMessage='';
                    }
                );
        }


        function removeUser(id){
            console.log('About to remove User with id '+id);
            UserService.removeUser(id)
                .then(
                    function(){
                        console.log('User '+id + ' removed successfully');
                    },
                    function(errResponse){
                        console.error('Error while removing user '+id +', Error :'+JSON.stringify(errResponse.data));
                    }
                );
        }


        function getAllUsers(){
            return UserService.getAllUsers();
        }
        
        function refreshList()
        {
        	self.user = {};
        	$scope.myForm.$setPristine();
        	UserService.loadAllUsers().then(
                    function(){
                    	self.successMessage='Refreshed successfully';
                        self.errorMessage='';
                    },
                    function(errResponse){
                    	self.successMessage='';
                        self.errorMessage='Some error while refresh.';
                    }
                );
         
        }

        function editUser(id) {
            self.successMessage='';
            self.errorMessage='';
            UserService.getUser(id).then(
                function (user) {
                    self.user = user;
                },
                function (errResponse) {
                    console.error('Error while retreiving user ' + id + ', Error :' + errResponse.data);
                }
            );
        }
        
        
        ////////////////////////////////////////////////////
        
        
        $scope.isLoggedIn = false;
         
    }


    ]);


