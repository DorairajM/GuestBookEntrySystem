'use strict';
var websiteApp = angular.module('guestBookEntryApp');
websiteApp.factory('LoginService', ['$resource','$http','$cookies',
        function ($resource,$http,$cookies) {

            var factory = {
                checkAccess: checkAccess,
                login:login
            };

            return factory;
            
            function checkAccess()
            {
	            var isLoginPage = window.location.href.indexOf("login") != -1;
	            
	            if(isLoginPage){
	            	console.log("is login page");
	                if($cookies.get("access_token")){
	                    window.location.href = "index";
	                }
	            }else{
	                if($cookies.get("access_token")){
	                	console.log("there is access token");
	                    $http.defaults.headers.common.Authorization= 'Bearer ' + $cookies.get("access_token");	                   
	                   
	                }else{
	                	// obtainAccessToken($scope.refreshData);
	                	console.log("there is noooo access token");	                   
	                    window.location.href = "login";
	                }
	            } 
            }
            
            function login(params)
            {
            	console.log(' login params :'+JSON.stringify(params));
            	var req = {            			 
                        method: 'POST',
                        url: "oauth/token",
                        headers: {"Content-type": "application/x-www-form-urlencoded; charset=utf-8"},
                        data: params
                    }
                    $http(req).then(
                        function(data){
                        	 console.log('  $http(req).then( :'+JSON.stringify(data));
                            $http.defaults.headers.common.Authorization= 'Bearer ' + data.data.access_token;
                            $window.localStorage.token=data.data.access_token;
                            var expireDate = new Date (new Date().getTime() + (1000 * data.data.expires_in));
                            $cookies.put("access_token", data.data.access_token, {'expires': expireDate});
                            $cookies.put("validity", data.data.expires_in);
                            window.location.href="home";
                        },function(){
                            console.log("error");
                            window.location.href = "login";
                        }
                    );
            }

        }
    ]);