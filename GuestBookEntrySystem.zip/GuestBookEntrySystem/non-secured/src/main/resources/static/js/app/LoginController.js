'use strict';
var websiteApp = angular.module('guestBookEntryApp');
websiteApp.controller('LoginController',
    ['LoginService','$scope','$httpParamSerializer',
     function( LoginService, $scope,$httpParamSerializer) {

        var self = this;
        
        self.loginData={};
        self.successMessage = '';
        self.errorMessage = '';
        
        self.submit = submit;
        self.reset = reset;
        
        $scope.isLoggedIn = false;
        
        function submit() {
        	$scope.loginData = {grant_type:"password", username: self.loginData.login, password: self.loginData.password, client_id: "testjwtclientid:XY7kmzoNzl100"};
        	var params = $httpParamSerializer($scope.loginData)
        	LoginService.login(params);
        }
        
        function reset() {        	
        	self.successMessage='';
            self.errorMessage='';
            self.loginData={};
            $scope.myForm.$setPristine();
        }
         
    }


    ]);