'use strict';
var websiteApp = angular.module('guestBookEntryApp');
websiteApp.factory('UserService',
    ['$localStorage', '$http', '$q', 'urls','$cookies',
        function ($localStorage, $http, $q, urls,$cookies) {

            var factory = {
                loadAllUsers: loadAllUsers,
                getAllUsers: getAllUsers,
                getUser: getUser,
                createUser: createUser,
                updateUser: updateUser,
                removeUser: removeUser
            };

            return factory;
             	 
          
            function checkAccess()
            {
//                var isLoginPage = window.location.href.indexOf("login") != -1;
//                                 
//                if(isLoginPage){
//                	console.log("is login page");
//                    if($cookies.get("access_token")){
//                        window.location.href = "index";
//                    }
//                }else{
//                	
//                    if($cookies.get("access_token")){
//                    	 
//                    	console.log("there is access token");
//                        $http.defaults.headers.common.Authorization= 'Bearer ' + $cookies.get("access_token");
//                        $scope.isLoggedIn = true;
//                    }else{
//                    	// obtainAccessToken($scope.refreshData);
//                    	console.log("there is noooo access token");                       
//                        window.location.href = "login";
//                        return false;
//                    }
//                }
//                
                return true;
            }

            function loadAllUsers() {            	
            	if(!checkAccess())
            		return;

                console.log('Fetching all users');
                var deferred = $q.defer();
                $http.get(urls.USER_SERVICE_API)
                    .then(
                        function (response) {
                            console.log('Fetched successfully all users');
                            
                            $localStorage.users = response.data;
                            console.log(' '+JSON.stringify($localStorage.users));
                            deferred.resolve(response);
                        },
                        function (errResponse) {alert(1);
                            console.error('Error while loading users');
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function getAllUsers(){
            	if(!checkAccess())
            		return;
               return $localStorage.users;
            	
            	//return loadAllUsers();
            }

            function getUser(id) {
            	if(!checkAccess())
            		return;
                console.log('Fetching User with id :'+id);
                var deferred = $q.defer();
                $http.get(urls.USER_SERVICE_API + id)
                    .then(
                        function (response) {
                            console.log('Fetched successfully User with id :'+id);
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while loading user with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function createUser(user) {
            	if(!checkAccess())
            		return;
                console.log('Creating User');
                var deferred = $q.defer();
                $http.post(urls.USER_SERVICE_API, user)
                    .then(
                        function (response) {
                            loadAllUsers();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                           console.error('Error while creating User : '+errResponse.data.errorMessage);
                           deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function updateUser(user, id) {
            	if(!checkAccess())
            		return;
                console.log('Updating User with id '+id);
                var deferred = $q.defer();
                $http.patch(urls.USER_SERVICE_API + id, user)
                    .then(
                        function (response) {
                            loadAllUsers();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while updating User with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function removeUser(id) {
            	if(!checkAccess())
            		return;
                console.log('Removing User with id '+id);
                var deferred = $q.defer();
                $http.delete(urls.USER_SERVICE_API + id)
                    .then(
                        function (response) {
                            loadAllUsers();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while removing User with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

        }
    ]);